﻿using DVLD___BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace DVLDWinForms___Presentation_Layer.Global_Classes
{
    public class clsGlobal
    {
        public static clsUser CurrentUser;
      
        private static string _FilePath = Directory.GetCurrentDirectory() + "\\data.txt";

        public static void SaveCredentials(string Username, string Password)
        {

            try
            {
                string Content = Username.Trim() + "#//#" + Password.Trim();

                // StreamWriter automatically create a file if it's not exist
                using(StreamWriter streamer = new StreamWriter(_FilePath))
                {
                    streamer.WriteLine(Content);
                }
                
            }
            catch (Exception e)
            {

            }
        }

        public static void ClearCredentials()
        {
            if (File.Exists(_FilePath))
                File.Delete(_FilePath);
        }

        public static bool GetStoredCredentials(ref string Username, ref string Password)
        {

            try
            {

                if (File.Exists(_FilePath))
                {
                    using(StreamReader Reader = new StreamReader(_FilePath))
                    {
                        string[] Content = Reader.ReadLine().Split(new String[] { "#//#" }, StringSplitOptions.None);

                        Username = Content[0];
                        Password = Content[1];
                        return true;                        
                    }

                }
                else
                {
                    return false;
                }

            }
            catch(Exception ex)
            {
                return false;
            }
        }

    }
}
