﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace DVLDWinForms___Presentation_Layer.Global_Classes
{
    public class clsImageHelper
    {
        private static string _FolderPath = @"C:\DVLD-Images\";

        public static string GenerateGUID()
        {
            Guid newGUID = Guid.NewGuid();
            return newGUID.ToString(); 
        }

        public static bool CreateFolderIfNotExists(string FolderPath)
        {
            if (Directory.Exists(FolderPath))
                return true;

            try
            {
                Directory.CreateDirectory(FolderPath);
                return true;
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public static string ReplaceFileNameWithGUID(string SourcePath)
        {
            // Get The extension of the file
            FileInfo file = new FileInfo(SourcePath);
            string extenstion = file.Extension;

            // return the file path
            return GenerateGUID() + extenstion;
        }

        public static bool CopyImageToImagesFolder(ref string SourcePath)
        {
            if(!CreateFolderIfNotExists(_FolderPath))
            {
                return false;
            }

            string DestinationPath = _FolderPath + ReplaceFileNameWithGUID(SourcePath);
            try
            {
                File.Copy(SourcePath, DestinationPath);
            }
            catch(IOException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            SourcePath = DestinationPath;
            return true;
        }

    }
}
