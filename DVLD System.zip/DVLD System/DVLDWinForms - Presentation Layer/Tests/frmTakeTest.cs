﻿using DVLD___BusinessLayer;
using DVLDWinForms___Presentation_Layer.Global_Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLDWinForms___Presentation_Layer.Tests
{
    public partial class frmTakeTest : Form
    {
        private int _TestAppointmentID = -1;
        private clsTestAppointment _TestAppointment;
        private clsTestType.enTestType _TestType;
        private clsTest _Test;

        public frmTakeTest(int TestAppointmentID, clsTestType.enTestType TestType)
        {
            InitializeComponent();

            _TestAppointmentID = TestAppointmentID;
            _TestType = TestType;
        }

        private void frmTakeTest_Load(object sender, EventArgs e)
        {
            ctrlTakeTest1.TestTypeID = _TestType;
            ctrlTakeTest1.LoadInfo(_TestAppointmentID);

            if (ctrlTakeTest1.TestAppointmentID == -1)
                btnSave.Enabled = false;
            else
                btnSave.Enabled = true;


            // When the test result is already exist
            if(ctrlTakeTest1.TestID != -1)
            {
                _Test = clsTest.Find(ctrlTakeTest1.TestID);
                lblMessage.Visible = true;
                rbFail.Enabled = false;
                rbPass.Enabled = false;
                rbPass.Checked = _Test.TestResult;
                rbFail.Checked = !_Test.TestResult;
                txtNotes.Text = _Test.Notes;
            }
            else
            {
                _Test = new clsTest();
            }

        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are You Sure you want to save?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
 
                _Test.TestAppointmentID = _TestAppointmentID;
                _Test.TestResult = rbPass.Checked;
                _Test.Notes = txtNotes.Text.Trim();
                _Test.CreatedByUserID = clsGlobal.CurrentUser.UserID;
                
                if(_Test.Save())
                {
                    MessageBox.Show("Data Saved Successfully.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Data Not Saved Successfully.", "Not Saved", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                this.Close();
            }
        }
    }
}
