﻿using DVLD___BusinessLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DVLDWinForms___Presentation_Layer.Test_Types
{
    public partial class frmUpdateTestTypes : Form
    {
        private clsTestType.enTestType _ID = clsTestType.enTestType.VisionTest;
        private clsTestType _TestType;

        public frmUpdateTestTypes(clsTestType.enTestType ID)
        {
            InitializeComponent();
            _ID = ID;
        }

        private void _FillTestTypeInfo()
        {
            lblID.Text = ((int)_TestType.ID).ToString();
            txtTitle.Text = _TestType.Title;
            txtDescription.Text = _TestType.Description;
            txtFees.Text = _TestType.Fees.ToString();
        }
        private void frmUpdateTestTypes_Load(object sender, EventArgs e)
        {
            _TestType = clsTestType.Find(_ID);

            if(_TestType == null)
            {
                MessageBox.Show("Test Type Does not exist");
                this.Close();
                return;
            }

            _FillTestTypeInfo();
        }

        private void _SaveTestTypeInfo()
        {
            _TestType.Title = txtTitle.Text.Trim();
            _TestType.Description = txtDescription.Text.Trim();
            _TestType.Fees = float.Parse(txtFees.Text.Trim());

            if(_TestType.Save())
            {
                MessageBox.Show("Data is Saved Successfully.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Data is not Saved Successfully.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if(!this.ValidateChildren())
            {
                MessageBox.Show("Some Fields are not valid, put the mouse over the red icon(s) to see the error", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            _SaveTestTypeInfo(); 
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void _ValidateEmptyTextBox(object sender, CancelEventArgs e)
        {
            TextBox textBox = (TextBox)sender;

            if (String.IsNullOrEmpty(textBox.Text.Trim()))
            {
                e.Cancel = true;
                errorProvider1.SetError(textBox, "This Field Can not be empty");
            }
            else
            {
                errorProvider1.SetError(textBox, null);
            }
        }
        private void txtTitle_Validating(object sender, CancelEventArgs e)
        {
            _ValidateEmptyTextBox(sender, e);
        }
        private void txtDescription_Validating(object sender, CancelEventArgs e)
        {
            _ValidateEmptyTextBox(sender, e);
        }


        private void txtFees_Validating(object sender, CancelEventArgs e)
        {
            // Validate non int values and negative numbers
            if (!float.TryParse(txtFees.Text.Trim(), out float Fees) || Fees < 0)
            {
                e.Cancel = true;
                errorProvider1.SetError(txtFees, "Invalid Number.");
                return;
            }

            errorProvider1.SetError(txtFees, null);
        }
    }
}
