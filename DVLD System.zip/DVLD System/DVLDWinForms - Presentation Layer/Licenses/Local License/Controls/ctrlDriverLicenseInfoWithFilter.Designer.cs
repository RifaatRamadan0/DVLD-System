﻿namespace DVLDWinForms___Presentation_Layer.Licenses.Local_License.Controls
{
    partial class ctrlDriverLicenseInfoWithFilter
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ctrlDriverLicenseInfoWithFilter));
            this.gbFilterLocalLicense = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtLocalLicenseID = new System.Windows.Forms.TextBox();
            this.btnFilterLocalLicense = new System.Windows.Forms.Button();
            this.ctrlDriverLicenseInfo1 = new DVLDWinForms___Presentation_Layer.Licenses.Local_License.Controls.ctrlDriverLicenseInfo();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.gbFilterLocalLicense.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // gbFilterLocalLicense
            // 
            this.gbFilterLocalLicense.Controls.Add(this.btnFilterLocalLicense);
            this.gbFilterLocalLicense.Controls.Add(this.txtLocalLicenseID);
            this.gbFilterLocalLicense.Controls.Add(this.label1);
            this.gbFilterLocalLicense.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbFilterLocalLicense.Location = new System.Drawing.Point(0, 0);
            this.gbFilterLocalLicense.Name = "gbFilterLocalLicense";
            this.gbFilterLocalLicense.Size = new System.Drawing.Size(653, 94);
            this.gbFilterLocalLicense.TabIndex = 1;
            this.gbFilterLocalLicense.TabStop = false;
            this.gbFilterLocalLicense.Text = "Filter";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "License ID:";
            // 
            // txtLocalLicenseID
            // 
            this.txtLocalLicenseID.Location = new System.Drawing.Point(142, 35);
            this.txtLocalLicenseID.Name = "txtLocalLicenseID";
            this.txtLocalLicenseID.Size = new System.Drawing.Size(326, 26);
            this.txtLocalLicenseID.TabIndex = 1;
            this.txtLocalLicenseID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLocalLicenseID_KeyPress);
            this.txtLocalLicenseID.Validating += new System.ComponentModel.CancelEventHandler(this.txtLocalLicenseID_Validating);
            // 
            // btnFilterLocalLicense
            // 
            this.btnFilterLocalLicense.Image = ((System.Drawing.Image)(resources.GetObject("btnFilterLocalLicense.Image")));
            this.btnFilterLocalLicense.Location = new System.Drawing.Point(525, 25);
            this.btnFilterLocalLicense.Name = "btnFilterLocalLicense";
            this.btnFilterLocalLicense.Size = new System.Drawing.Size(77, 45);
            this.btnFilterLocalLicense.TabIndex = 2;
            this.btnFilterLocalLicense.UseVisualStyleBackColor = true;
            this.btnFilterLocalLicense.Click += new System.EventHandler(this.btnFilterLocalLicense_Click);
            // 
            // ctrlDriverLicenseInfo1
            // 
            this.ctrlDriverLicenseInfo1.Location = new System.Drawing.Point(0, 100);
            this.ctrlDriverLicenseInfo1.Name = "ctrlDriverLicenseInfo1";
            this.ctrlDriverLicenseInfo1.Size = new System.Drawing.Size(912, 378);
            this.ctrlDriverLicenseInfo1.TabIndex = 0;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // ctrlDriverLicenseInfoWithFilter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.Controls.Add(this.gbFilterLocalLicense);
            this.Controls.Add(this.ctrlDriverLicenseInfo1);
            this.Name = "ctrlDriverLicenseInfoWithFilter";
            this.Size = new System.Drawing.Size(915, 479);
            this.gbFilterLocalLicense.ResumeLayout(false);
            this.gbFilterLocalLicense.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ctrlDriverLicenseInfo ctrlDriverLicenseInfo1;
        private System.Windows.Forms.GroupBox gbFilterLocalLicense;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtLocalLicenseID;
        private System.Windows.Forms.Button btnFilterLocalLicense;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}
