﻿namespace DVLDWinForms___Presentation_Layer
{
    partial class frmMainDVLD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainDVLD));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblUserLoggedIn = new System.Windows.Forms.Label();
            this.MenuDVLD = new System.Windows.Forms.MenuStrip();
            this.MenuApplications = new System.Windows.Forms.ToolStripMenuItem();
            this.drivingLicensesServicesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuNewLicense = new System.Windows.Forms.ToolStripMenuItem();
            this.localLicenseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.internationalLicenseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuRenewLicense = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuReplaceLicense = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuReleaseLicense = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuRetakeTest = new System.Windows.Forms.ToolStripMenuItem();
            this.manageApplicationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.localLicenseApplicationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.internationalDrivingLicenseApplicationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuReleaseDetainedLicense = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuManageDetainedLicenses = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuDetainLicense = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuRelease = new System.Windows.Forms.ToolStripMenuItem();
            this.manageApplicationTypesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.manageTestTypesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuPeople = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuDrivers = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuUsers = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuAccountSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuUserInfo = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuChangePassword = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuSignOut = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.MenuDVLD.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(643, 266);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(519, 423);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(783, 707);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "User Logged In: ";
            // 
            // lblUserLoggedIn
            // 
            this.lblUserLoggedIn.AutoSize = true;
            this.lblUserLoggedIn.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserLoggedIn.Location = new System.Drawing.Point(932, 707);
            this.lblUserLoggedIn.Name = "lblUserLoggedIn";
            this.lblUserLoggedIn.Size = new System.Drawing.Size(36, 19);
            this.lblUserLoggedIn.TabIndex = 2;
            this.lblUserLoggedIn.Text = "???";
            // 
            // MenuDVLD
            // 
            this.MenuDVLD.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuDVLD.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuApplications,
            this.MenuPeople,
            this.MenuDrivers,
            this.MenuUsers,
            this.MenuAccountSettings});
            this.MenuDVLD.Location = new System.Drawing.Point(0, 0);
            this.MenuDVLD.Name = "MenuDVLD";
            this.MenuDVLD.Size = new System.Drawing.Size(1390, 72);
            this.MenuDVLD.TabIndex = 3;
            this.MenuDVLD.Text = "MenuDVLD";
            // 
            // MenuApplications
            // 
            this.MenuApplications.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.drivingLicensesServicesToolStripMenuItem,
            this.manageApplicationsToolStripMenuItem,
            this.MenuReleaseDetainedLicense,
            this.manageApplicationTypesToolStripMenuItem,
            this.manageTestTypesToolStripMenuItem});
            this.MenuApplications.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuApplications.Image = ((System.Drawing.Image)(resources.GetObject("MenuApplications.Image")));
            this.MenuApplications.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuApplications.Name = "MenuApplications";
            this.MenuApplications.Size = new System.Drawing.Size(182, 68);
            this.MenuApplications.Text = "Applications";
            // 
            // drivingLicensesServicesToolStripMenuItem
            // 
            this.drivingLicensesServicesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuNewLicense,
            this.MenuRenewLicense,
            this.MenuReplaceLicense,
            this.MenuReleaseLicense,
            this.MenuRetakeTest});
            this.drivingLicensesServicesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.drivingLicensesServicesToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("drivingLicensesServicesToolStripMenuItem.Image")));
            this.drivingLicensesServicesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.drivingLicensesServicesToolStripMenuItem.Name = "drivingLicensesServicesToolStripMenuItem";
            this.drivingLicensesServicesToolStripMenuItem.Size = new System.Drawing.Size(365, 70);
            this.drivingLicensesServicesToolStripMenuItem.Text = "Driving Licenses Services";
            // 
            // MenuNewLicense
            // 
            this.MenuNewLicense.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.localLicenseToolStripMenuItem,
            this.internationalLicenseToolStripMenuItem});
            this.MenuNewLicense.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuNewLicense.Image = ((System.Drawing.Image)(resources.GetObject("MenuNewLicense.Image")));
            this.MenuNewLicense.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuNewLicense.Name = "MenuNewLicense";
            this.MenuNewLicense.Size = new System.Drawing.Size(356, 38);
            this.MenuNewLicense.Text = "New Driving License";
            // 
            // localLicenseToolStripMenuItem
            // 
            this.localLicenseToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("localLicenseToolStripMenuItem.Image")));
            this.localLicenseToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.localLicenseToolStripMenuItem.Name = "localLicenseToolStripMenuItem";
            this.localLicenseToolStripMenuItem.Size = new System.Drawing.Size(221, 38);
            this.localLicenseToolStripMenuItem.Text = "Local License";
            this.localLicenseToolStripMenuItem.Click += new System.EventHandler(this.localLicenseToolStripMenuItem_Click);
            // 
            // internationalLicenseToolStripMenuItem
            // 
            this.internationalLicenseToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("internationalLicenseToolStripMenuItem.Image")));
            this.internationalLicenseToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.internationalLicenseToolStripMenuItem.Name = "internationalLicenseToolStripMenuItem";
            this.internationalLicenseToolStripMenuItem.Size = new System.Drawing.Size(221, 38);
            this.internationalLicenseToolStripMenuItem.Text = "International License";
            this.internationalLicenseToolStripMenuItem.Click += new System.EventHandler(this.internationalLicenseToolStripMenuItem_Click);
            // 
            // MenuRenewLicense
            // 
            this.MenuRenewLicense.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuRenewLicense.Image = ((System.Drawing.Image)(resources.GetObject("MenuRenewLicense.Image")));
            this.MenuRenewLicense.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuRenewLicense.Name = "MenuRenewLicense";
            this.MenuRenewLicense.Size = new System.Drawing.Size(356, 38);
            this.MenuRenewLicense.Text = "Renew Driving License";
            this.MenuRenewLicense.Click += new System.EventHandler(this.MenuRenewLicense_Click);
            // 
            // MenuReplaceLicense
            // 
            this.MenuReplaceLicense.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuReplaceLicense.Image = ((System.Drawing.Image)(resources.GetObject("MenuReplaceLicense.Image")));
            this.MenuReplaceLicense.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuReplaceLicense.Name = "MenuReplaceLicense";
            this.MenuReplaceLicense.Size = new System.Drawing.Size(356, 38);
            this.MenuReplaceLicense.Text = "Replacement for Lost or Damaged License";
            this.MenuReplaceLicense.Click += new System.EventHandler(this.MenuReplaceLicense_Click);
            // 
            // MenuReleaseLicense
            // 
            this.MenuReleaseLicense.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuReleaseLicense.Image = ((System.Drawing.Image)(resources.GetObject("MenuReleaseLicense.Image")));
            this.MenuReleaseLicense.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuReleaseLicense.Name = "MenuReleaseLicense";
            this.MenuReleaseLicense.Size = new System.Drawing.Size(356, 38);
            this.MenuReleaseLicense.Text = "Release Detained Driving License";
            this.MenuReleaseLicense.Click += new System.EventHandler(this.MenuReleaseLicense_Click);
            // 
            // MenuRetakeTest
            // 
            this.MenuRetakeTest.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuRetakeTest.Image = ((System.Drawing.Image)(resources.GetObject("MenuRetakeTest.Image")));
            this.MenuRetakeTest.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuRetakeTest.Name = "MenuRetakeTest";
            this.MenuRetakeTest.Size = new System.Drawing.Size(356, 38);
            this.MenuRetakeTest.Text = "Retake Test";
            // 
            // manageApplicationsToolStripMenuItem
            // 
            this.manageApplicationsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.localLicenseApplicationsToolStripMenuItem,
            this.internationalDrivingLicenseApplicationsToolStripMenuItem});
            this.manageApplicationsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manageApplicationsToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("manageApplicationsToolStripMenuItem.Image")));
            this.manageApplicationsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.manageApplicationsToolStripMenuItem.Name = "manageApplicationsToolStripMenuItem";
            this.manageApplicationsToolStripMenuItem.Size = new System.Drawing.Size(365, 70);
            this.manageApplicationsToolStripMenuItem.Text = "Manage Applications";
            // 
            // localLicenseApplicationsToolStripMenuItem
            // 
            this.localLicenseApplicationsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.localLicenseApplicationsToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("localLicenseApplicationsToolStripMenuItem.Image")));
            this.localLicenseApplicationsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.localLicenseApplicationsToolStripMenuItem.Name = "localLicenseApplicationsToolStripMenuItem";
            this.localLicenseApplicationsToolStripMenuItem.Size = new System.Drawing.Size(308, 38);
            this.localLicenseApplicationsToolStripMenuItem.Text = "Local Driving License Applications";
            this.localLicenseApplicationsToolStripMenuItem.Click += new System.EventHandler(this.localLicenseApplicationsToolStripMenuItem_Click);
            // 
            // internationalDrivingLicenseApplicationsToolStripMenuItem
            // 
            this.internationalDrivingLicenseApplicationsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.internationalDrivingLicenseApplicationsToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("internationalDrivingLicenseApplicationsToolStripMenuItem.Image")));
            this.internationalDrivingLicenseApplicationsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.internationalDrivingLicenseApplicationsToolStripMenuItem.Name = "internationalDrivingLicenseApplicationsToolStripMenuItem";
            this.internationalDrivingLicenseApplicationsToolStripMenuItem.Size = new System.Drawing.Size(308, 38);
            this.internationalDrivingLicenseApplicationsToolStripMenuItem.Text = "International License Applications";
            this.internationalDrivingLicenseApplicationsToolStripMenuItem.Click += new System.EventHandler(this.internationalDrivingLicenseApplicationsToolStripMenuItem_Click);
            // 
            // MenuReleaseDetainedLicense
            // 
            this.MenuReleaseDetainedLicense.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuManageDetainedLicenses,
            this.MenuDetainLicense,
            this.MenuRelease});
            this.MenuReleaseDetainedLicense.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuReleaseDetainedLicense.Image = ((System.Drawing.Image)(resources.GetObject("MenuReleaseDetainedLicense.Image")));
            this.MenuReleaseDetainedLicense.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuReleaseDetainedLicense.Name = "MenuReleaseDetainedLicense";
            this.MenuReleaseDetainedLicense.Size = new System.Drawing.Size(365, 70);
            this.MenuReleaseDetainedLicense.Text = "Detain Licenses";
            // 
            // MenuManageDetainedLicenses
            // 
            this.MenuManageDetainedLicenses.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuManageDetainedLicenses.Image = ((System.Drawing.Image)(resources.GetObject("MenuManageDetainedLicenses.Image")));
            this.MenuManageDetainedLicenses.Name = "MenuManageDetainedLicenses";
            this.MenuManageDetainedLicenses.Size = new System.Drawing.Size(261, 38);
            this.MenuManageDetainedLicenses.Text = "Manage Detained Licenses";
            this.MenuManageDetainedLicenses.Click += new System.EventHandler(this.MenuManageDetainedLicenses_Click);
            // 
            // MenuDetainLicense
            // 
            this.MenuDetainLicense.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuDetainLicense.Image = ((System.Drawing.Image)(resources.GetObject("MenuDetainLicense.Image")));
            this.MenuDetainLicense.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuDetainLicense.Name = "MenuDetainLicense";
            this.MenuDetainLicense.Size = new System.Drawing.Size(261, 38);
            this.MenuDetainLicense.Text = "Detain License";
            this.MenuDetainLicense.Click += new System.EventHandler(this.MenuDetainLicense_Click);
            // 
            // MenuRelease
            // 
            this.MenuRelease.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MenuRelease.Image = ((System.Drawing.Image)(resources.GetObject("MenuRelease.Image")));
            this.MenuRelease.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuRelease.Name = "MenuRelease";
            this.MenuRelease.Size = new System.Drawing.Size(261, 38);
            this.MenuRelease.Text = "Release Detained License";
            this.MenuRelease.Click += new System.EventHandler(this.MenuRelease_Click);
            // 
            // manageApplicationTypesToolStripMenuItem
            // 
            this.manageApplicationTypesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manageApplicationTypesToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("manageApplicationTypesToolStripMenuItem.Image")));
            this.manageApplicationTypesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.manageApplicationTypesToolStripMenuItem.Name = "manageApplicationTypesToolStripMenuItem";
            this.manageApplicationTypesToolStripMenuItem.Size = new System.Drawing.Size(365, 70);
            this.manageApplicationTypesToolStripMenuItem.Text = "Manage Application Types";
            this.manageApplicationTypesToolStripMenuItem.Click += new System.EventHandler(this.manageApplicationTypesToolStripMenuItem_Click);
            // 
            // manageTestTypesToolStripMenuItem
            // 
            this.manageTestTypesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.manageTestTypesToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("manageTestTypesToolStripMenuItem.Image")));
            this.manageTestTypesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.manageTestTypesToolStripMenuItem.Name = "manageTestTypesToolStripMenuItem";
            this.manageTestTypesToolStripMenuItem.Size = new System.Drawing.Size(365, 70);
            this.manageTestTypesToolStripMenuItem.Text = "Manage Test Types";
            this.manageTestTypesToolStripMenuItem.Click += new System.EventHandler(this.manageTestTypesToolStripMenuItem_Click);
            // 
            // MenuPeople
            // 
            this.MenuPeople.Image = ((System.Drawing.Image)(resources.GetObject("MenuPeople.Image")));
            this.MenuPeople.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuPeople.Name = "MenuPeople";
            this.MenuPeople.Size = new System.Drawing.Size(139, 68);
            this.MenuPeople.Text = "People";
            this.MenuPeople.Click += new System.EventHandler(this.MenuPeople_Click);
            // 
            // MenuDrivers
            // 
            this.MenuDrivers.Image = ((System.Drawing.Image)(resources.GetObject("MenuDrivers.Image")));
            this.MenuDrivers.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuDrivers.Name = "MenuDrivers";
            this.MenuDrivers.Size = new System.Drawing.Size(140, 68);
            this.MenuDrivers.Text = "Drivers";
            this.MenuDrivers.Click += new System.EventHandler(this.MenuDrivers_Click);
            // 
            // MenuUsers
            // 
            this.MenuUsers.Image = ((System.Drawing.Image)(resources.GetObject("MenuUsers.Image")));
            this.MenuUsers.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuUsers.Name = "MenuUsers";
            this.MenuUsers.Size = new System.Drawing.Size(127, 68);
            this.MenuUsers.Text = "Users";
            this.MenuUsers.Click += new System.EventHandler(this.MenuUsers_Click);
            // 
            // MenuAccountSettings
            // 
            this.MenuAccountSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuUserInfo,
            this.MenuChangePassword,
            this.MenuSignOut});
            this.MenuAccountSettings.Image = ((System.Drawing.Image)(resources.GetObject("MenuAccountSettings.Image")));
            this.MenuAccountSettings.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuAccountSettings.Name = "MenuAccountSettings";
            this.MenuAccountSettings.Size = new System.Drawing.Size(215, 68);
            this.MenuAccountSettings.Text = "Account Settings";
            // 
            // MenuUserInfo
            // 
            this.MenuUserInfo.Image = ((System.Drawing.Image)(resources.GetObject("MenuUserInfo.Image")));
            this.MenuUserInfo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuUserInfo.Name = "MenuUserInfo";
            this.MenuUserInfo.Size = new System.Drawing.Size(230, 38);
            this.MenuUserInfo.Text = "Current User Info";
            this.MenuUserInfo.Click += new System.EventHandler(this.MenuUserInfo_Click);
            // 
            // MenuChangePassword
            // 
            this.MenuChangePassword.Image = ((System.Drawing.Image)(resources.GetObject("MenuChangePassword.Image")));
            this.MenuChangePassword.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuChangePassword.Name = "MenuChangePassword";
            this.MenuChangePassword.Size = new System.Drawing.Size(230, 38);
            this.MenuChangePassword.Text = "Change Password";
            this.MenuChangePassword.Click += new System.EventHandler(this.MenuChangePassword_Click);
            // 
            // MenuSignOut
            // 
            this.MenuSignOut.Image = ((System.Drawing.Image)(resources.GetObject("MenuSignOut.Image")));
            this.MenuSignOut.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.MenuSignOut.Name = "MenuSignOut";
            this.MenuSignOut.Size = new System.Drawing.Size(230, 38);
            this.MenuSignOut.Text = "Sign Out";
            this.MenuSignOut.Click += new System.EventHandler(this.MenuSignOut_Click);
            // 
            // frmMainDVLD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1390, 762);
            this.Controls.Add(this.lblUserLoggedIn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.MenuDVLD);
            this.MainMenuStrip = this.MenuDVLD;
            this.Name = "frmMainDVLD";
            this.Text = "Main";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMainDVLD_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.MenuDVLD.ResumeLayout(false);
            this.MenuDVLD.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblUserLoggedIn;
        private System.Windows.Forms.MenuStrip MenuDVLD;
        private System.Windows.Forms.ToolStripMenuItem MenuApplications;
        private System.Windows.Forms.ToolStripMenuItem MenuPeople;
        private System.Windows.Forms.ToolStripMenuItem MenuDrivers;
        private System.Windows.Forms.ToolStripMenuItem MenuUsers;
        private System.Windows.Forms.ToolStripMenuItem MenuAccountSettings;
        private System.Windows.Forms.ToolStripMenuItem MenuUserInfo;
        private System.Windows.Forms.ToolStripMenuItem MenuChangePassword;
        private System.Windows.Forms.ToolStripMenuItem MenuSignOut;
        private System.Windows.Forms.ToolStripMenuItem drivingLicensesServicesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageApplicationsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuReleaseDetainedLicense;
        private System.Windows.Forms.ToolStripMenuItem manageApplicationTypesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageTestTypesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuNewLicense;
        private System.Windows.Forms.ToolStripMenuItem MenuRenewLicense;
        private System.Windows.Forms.ToolStripMenuItem MenuReplaceLicense;
        private System.Windows.Forms.ToolStripMenuItem MenuReleaseLicense;
        private System.Windows.Forms.ToolStripMenuItem MenuRetakeTest;
        private System.Windows.Forms.ToolStripMenuItem MenuManageDetainedLicenses;
        private System.Windows.Forms.ToolStripMenuItem MenuDetainLicense;
        private System.Windows.Forms.ToolStripMenuItem MenuRelease;
        private System.Windows.Forms.ToolStripMenuItem localLicenseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem internationalLicenseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem localLicenseApplicationsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem internationalDrivingLicenseApplicationsToolStripMenuItem;
    }
}

