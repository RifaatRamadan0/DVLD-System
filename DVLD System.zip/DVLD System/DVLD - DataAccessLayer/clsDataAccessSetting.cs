﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DVLD___DataAccessLayer
{
    internal class clsDataAccessSetting
    {
        static public string ConnectionString = "Server = .; Database = DVLD; User id = sa; password = sa123456";
    }
}
